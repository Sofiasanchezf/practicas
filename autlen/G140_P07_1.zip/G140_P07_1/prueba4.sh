make clean
make
./prueba4
dot -Tpng afd.dot > pruebas/prueba4.png
make clean
