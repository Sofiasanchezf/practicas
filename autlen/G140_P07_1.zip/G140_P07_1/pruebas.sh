make clean
make
./prueba1
dot -Tpng afd.dot > pruebas/prueba1.png

./prueba2
dot -Tpng afd.dot > pruebas/prueba2.png

./prueba3
dot -Tpng afd.dot > pruebas/prueba3.png

./prueba4
dot -Tpng afd.dot > pruebas/prueba4.png

./prueba5
dot -Tpng afd.dot > pruebas/prueba5.png

make clean
