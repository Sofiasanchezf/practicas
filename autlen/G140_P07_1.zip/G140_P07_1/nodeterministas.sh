make clean
make
./prueba1
dot -Tpng prueba1.dot > originales/prueba1.png

./prueba2
dot -Tpng prueba2.dot > originales/prueba2.png

./prueba3
dot -Tpng prueba3.dot > originales/prueba3.png

./prueba4
dot -Tpng prueba4.dot > originales/prueba4.png

./prueba5
dot -Tpng prueba5.dot > originales/prueba5.png

make clean
